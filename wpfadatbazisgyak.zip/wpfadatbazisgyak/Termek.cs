﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wpfadatbazisgyak
{
    internal class Termek
    {
        string _Kategoria;
        string _Gyarto;
        string _Nev;
        int _Ar;
        int _Garido;

        public Termek(string kategoria, string gyarto, string nev, int ar, int garido)
        {
            this.Kategoria = kategoria;
            this.Gyarto = gyarto;
            this.Nev = nev;
            this.Ar = ar;
            this.Garido = garido;
        }

        public String ToCSVString()
        {
            return $"{this.Kategoria};{this.Gyarto};{this.Nev};{this.Ar};{this.Garido}";
        }

        public string Kategoria { get => _Kategoria; set => _Kategoria = value; }
        public string Gyarto { get => _Gyarto; set => _Gyarto = value; }
        public string Nev { get => _Nev; set => _Nev = value; }
        public int Ar { get => _Ar; set => _Ar = value; }
        public int Garido { get => _Garido; set => _Garido = value; }
    }
}
